package models

type Test struct {
	Data string `json:"data"`
	Key  string `json:"key"`
	Raw  string `json:"raw"`
}
